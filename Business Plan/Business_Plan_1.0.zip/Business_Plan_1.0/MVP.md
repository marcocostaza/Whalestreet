# MVP

No.: 11
Status: Done

### Qual è il servizio MINIMO che si vuole offrire per iniziare a reclutare studenti?

- Gruppo Telegram funzionante 24/7
- Pubblicazione di un video commento del report testuale al mese
- NotebookLM che contiene le trascrizioni delle lezioni attualmente presenti

### Che sezioni del marketing devono essere aperte?

- Homepage del sito che spiega i nostri servizi
- Roadmap pubblica che mostra gli update che vogliamo portare al progetto
- Funnel iscrizione tramite XTB di Marco
- Funnel “breve” di conversione tramite report scritto di Mattia
    - Scarica il report lasciando la mail
        - Vendita dell’upgrade nel report stesso